package com.cognizant.exception;

public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5181289142972939923L;

	public EmployeeException(){
		
	}
	
	public EmployeeException(String message){
		super(message);
	}
}

package com.cognizant.service;

import java.util.List;

import com.cognizant.model.Employee;

public interface EmployeeService {
	int insertEmployee(Employee employee);
	int updateEmployee(Employee employee);
	int deleteEmployee(Employee employee);
	List<Employee> viewEmployee();
}

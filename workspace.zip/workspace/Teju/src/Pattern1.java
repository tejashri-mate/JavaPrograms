
public class Pattern1 {

	public static void main(String[] args) {
		int k=0;
		for(int i=0;i<=5;i++)
		{
			k=1;
			for(int j=1;j<=(5+i);j++){
				if(j<5-i-1){
				System.out.print(" ");	
				}
				System.out.print(""+k);
				if(j<(5-1))
				k++;
				else
					k--;
			}
			System.out.println();
		}
	}
	}

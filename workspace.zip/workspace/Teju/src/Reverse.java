import java.util.*;
public class Reverse {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i,rem=0,rev=0;
		System.out.println("enter size ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("enter all the elements");
		for( i=0;i<n;i++){
			arr[i]=sc.nextInt();
		}
		for(i=n-1;i>=0;i--){
			//rem=n%10;
			//rev=rev*10+n;
			//n=n/10;
			System.out.println(arr[i]);
		}
		
		}

}

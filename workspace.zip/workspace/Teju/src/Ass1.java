import java.util.*;
public class Ass1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int grade=0,basic=0;
		double salary=0.0;
		double da=0.0,hra=0.0,pf=0.0;
		System.out.println("Enter grade: ");
		grade=sc.nextInt();
		
		if(grade==1)
		{
			 basic=25000;
			 da=0.2*basic;
			 hra=0.3*basic;
			 pf=0.15*basic;
		}
		else if(grade ==2)
		{
			basic=35000;
			da=0.25*basic;
			hra=0.35*basic;
			pf=0.20*basic;
		}
		else if(grade==3){
			basic=55000;
			da=0.30*basic;
			hra=0.40*basic;
			pf=0.25*basic;
		}
		salary=basic+da+hra-pf;
		System.out.println("salary= "+salary);
	}

}

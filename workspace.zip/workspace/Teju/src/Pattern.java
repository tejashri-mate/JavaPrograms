
public class Pattern {

	public static void main(String[] args) {
		for(int i=1;i<=4;i++){
			for(int j=4;j>=1;j--){
				if(j>1){
				System.out.print(" ");
				}
				else
				{
					System.out.print(" *");
				}
			}
				System.out.println();
		}
		
		/*int k=0;
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=(5-i);j++)
			{
				System.out.print(" ");
			}
			while( k!=(i-1))
			{
				System.out.print("* ");
				k++;
			
			}
			k=0;
			System.out.println();
		}*/

	}

}

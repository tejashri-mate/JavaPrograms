package com.cognizant.entity;
import java.util.*;
public class Employee {
	private static float totalSalary;
	private int empid;
	private String name;
	private float salary;
	private Address address;
		/*public void input(int eid,String nam,float sal){
			empid=eid;
			name=nam;
			salary=sal;
		}*/
	static {
		eid=0;
	}
	public Employee(){
		
	}
	public Employee(String name,Address address,float salary){
		this.empid=empid;
		this.name=name;
		this.address=address;
		this.salary=salary;
		totalSalary += this.salary;
	}
	public  Employee(int empid,String name,float salary){
		this.empid=empid;
		this.name=name;
		this.salary=salary;
		totalSalary += this.salary;
	}
		public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
		public void output(){
			System.out.println("Employee id: "+empid);
			System.out.println("name: "+name);
			System.out.println("salary: "+salary);
		}
		public static void printSalary()
		{
			System.out.println("total sal:"+totalSalary);
		}
	}


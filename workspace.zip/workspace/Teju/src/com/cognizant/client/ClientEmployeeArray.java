//import java.util.Scanner;
package com.cognizant.client;

import java.util.Scanner;

import com.cognizant.entity.Employee;

public class ClientEmployeeArray {

	public static void main(String[] args) {
		Employee employees[]=new Employee[3];
		String name;
		float salary;
		
		Scanner sc=new Scanner(System.in);
		
		for(int i=0;i<employees.length;i++){
			System.out.println("enter name:");
			name=sc.nextLine();
			
			System.out.println("enter salary:");
			salary=sc.nextFloat();	
			
		}
		
		for(Employee employee:employees){
			employee.output();
		}
		
	}

}

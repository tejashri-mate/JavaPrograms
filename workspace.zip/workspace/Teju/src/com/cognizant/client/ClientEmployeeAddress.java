package com.cognizant.client;

import java.util.Scanner;

import com.cognizant.entity.Employee;
import com.cognizant.entity.Address;

public class ClientEmployeeAddress {

	public static void main(String[] args) {
		//Employee employees[]=new Employee[3];
		String name;
		float salary;
		
		String city;
		String state;
		
		Scanner sc=new Scanner(System.in);
		
		//for(int i=0;i<employees.length;i++){
			System.out.println("enter name:");
			name=sc.nextLine();
			
			System.out.println("enter salary:");
			salary=sc.nextFloat();	
			
			System.out.println("enter city:");
			city=sc.nextLine();	
			
			System.out.println("enter state:");
			state=sc.nextLine();
			
			Address address=new Address(city,state);
			
			Employee employee= new Employee(empid,name,salary);
			employee.output();
		}

	}

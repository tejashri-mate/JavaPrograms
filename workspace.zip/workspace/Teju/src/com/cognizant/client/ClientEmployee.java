package com.cognizant.client;
import java.util.*;

import com.cognizant.entity.Employee;
public class ClientEmployee {

	public static void main(String[] args) {
		 int empid;
		 String name;
		 float salary;
		 Scanner sc=new Scanner(System.in);
		 
		 System.out.println("enter emp id:");
		 empid=sc.nextInt();
		       sc.nextLine();
		       
		 System.out.println("enter name:");
				 name= sc.nextLine();
				       
		  System.out.println("enter salary:");
						 salary=sc.nextFloat();
						       sc.nextLine();	       
		//Employee employee = new Employee();
		Employee employee = new Employee(empid,name,salary);
		//employee.input(799215,"tej",22000);
		employee.output();
		employee.setSalary(50000);
		Employee.printSalary();
		employee.output();

	}

}


public class JaggedArray {

	public static void main(String[] args) {
		int array[][]= new int[3][];
		for(int i=0;i<array.length;i++){
			array[i]=new int[i+1];
		}
		for(int row=0,element=0;row<array.length;row++){
			for(int col=0;col<array[row].length;col++){
				array[row][col]= ++element;
			}
		}
			for(int row=0,element=0;row<array.length;row++){
				for(int col=0;col<array[row].length;col++){
					System.out.print(array[row][col]+"\t");
				}
				System.out.println();
		}
		
}
}

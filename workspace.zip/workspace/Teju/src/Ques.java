
public class Ques {

	public static void main(String[] args) {
		//System.out.println("1"+2+3);
		/*byte b=(byte) 128;
		int i=b;
		System.out.println(i);*/
		int i=0;
		int j;
		for(j=0;j<10;++j){
			i++;
		}
		System.out.println(+i+j);
	}

}

package com.bvk.client;

public class ExceptionDemo {

	public static void main(String[] args) {
		int a[] = {1,2,3};
		//try{
			for(int i = 0 ; i < a.length ; i++){
				System.out.println(a[i]);
			}
		/*}catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("Please don't go beyond bounds. Error occured at position: " + ae.getMessage());
		}*/
	}
}
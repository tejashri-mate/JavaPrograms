package com.bvk.client;

public class WithFinally {
	public static void main(String[] args) {
		int num = 0;
		try {
			num = 10 / 5;// No Exception
			//num = 10 / 0;// Will cause exception.
			System.out.println("Answer is: " + num);// Will not reach here, if
			//System.exit(0);									// exception thrown
		}catch (ArithmeticException ae) {
			System.out.println("Exception handled here: " + ae.getMessage());
		}finally {
			System.out.println("Inside finally");
		}
		System.out.println("After handling exception... ");
	}
}
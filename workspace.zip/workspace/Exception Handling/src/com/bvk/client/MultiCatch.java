package com.bvk.client;

public class MultiCatch {
	public static void main(String[] args) {
		int divisors[] = {5,10,0};
		
		for(int i = 0 ; i < 5 ; i++){
			try{
				System.out.println(100/divisors[i]);
			}catch(ArrayIndexOutOfBoundsException | ArithmeticException ae){
				// jdk 1.7
				System.out.println("Error Message(Index or divide by zero): "+ae.getMessage());
			}
		}
	}
}
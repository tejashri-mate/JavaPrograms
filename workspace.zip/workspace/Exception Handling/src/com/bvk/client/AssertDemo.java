package com.bvk.client;

public class AssertDemo {

	public static void main(String[] args) {
		int a = 9;
		
		assert(a==10):"a must be 10. it is "+a;//AssertionError
		System.out.println("Okay");
	}
}
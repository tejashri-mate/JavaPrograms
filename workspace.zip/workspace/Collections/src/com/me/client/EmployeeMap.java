package com.me.client;

import java.util.Collections;
import java.util.Set;
import java.util.TreeMap;

import com.me.entity.Employee;

public class EmployeeMap {

	public static void main(String[] args) {
		TreeMap<Integer, Employee>employeeMap = new TreeMap<Integer, Employee>(Collections.reverseOrder());
		
		
		Employee employee = new Employee(1, "abc", 90000);
		Employee employeeOne = new Employee(2, "xyz", 130000);
		Employee employeeTwo = new Employee(5, "pqr", 120000);
		
		employeeMap.put(employee.getEmpid(), employee);
		employeeMap.put(employeeTwo.getEmpid(), employeeTwo);
		employeeMap.put(employeeOne.getEmpid(), employeeOne);
		
		Set<Integer>keys = employeeMap.keySet();
		
		for (Integer key : keys) {
			System.out.println(employeeMap.get(key));
		}
		/*System.out.println("Salary of empid " + employeeOne.getEmpid() +
				" is " + employeeMap.get(employeeOne.getEmpid()).getSalary());*/
	}
}
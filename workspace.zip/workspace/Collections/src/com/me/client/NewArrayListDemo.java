package com.me.client;

import java.util.ArrayList;
import java.util.List;

public class NewArrayListDemo {

	public static void main(String[] args) {
		List<Integer>numbers = new ArrayList<>();
		List<Integer>duplicateNmbers = new ArrayList<>();
		
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		duplicateNmbers.addAll(numbers);
		duplicateNmbers.remove(1);
		duplicateNmbers.add(100);
		//duplicateNmbers.add(88);
		
		if(numbers.contains(100)){
			System.out.println("Present");
		}else{
			System.out.println("Not Present");
		}
		
		if(numbers.containsAll(duplicateNmbers)){
			System.out.println("Present");
		}else{
			System.out.println("Not Present");
		}
	}
}
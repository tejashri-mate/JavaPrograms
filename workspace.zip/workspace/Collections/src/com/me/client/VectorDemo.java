package com.me.client;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class VectorDemo {
	public static void main(String[] args) {
		Vector<String>alphabets = new Vector<String>(3,4);
		// 3 is initial capacity & 4 is extension factor, when you stretch its capacity.
		
		System.out.println("Initial Capacity: " + alphabets.capacity());
		
		alphabets.add("Hello");
		alphabets.add("hi");
		alphabets.add("good morning");
		alphabets.add("hi");
		
		System.out.println("Capacity after adding elements: " + alphabets.capacity());
		
		System.out.println(alphabets);
		
		alphabets.add(1, "bye");
		int size = alphabets.size();
		
		System.out.println("Using simple for loop:");
		for(int i = 0 ; i < size ; i++){
			System.out.println(alphabets.get(i));
		}
		
		Iterator<String>itr = alphabets.iterator();
		ListIterator<String>ltr = alphabets.listIterator();
		
		System.out.println("Using Iterator:");
		
		while(itr.hasNext()){
			String text = itr.next();
			System.out.println(text);
			//itr.remove();
			//numbers.add(90); Adding elements while using iterator is not allowed.
		}
		
		System.out.println("Using List Iterator:");
		
		while(ltr.hasNext()){
			String text = ltr.next();
			System.out.println(text);
			ltr.add("hi again!");//This is add method of List Iterator & not ArrayList. Hence, valid.
			//numbers.add(55);//Throws ConcurrentModificationException.
		}
		
		System.out.println("Using List Iterator in reverse order:");
		
		while(ltr.hasPrevious()){
			String text = ltr.previous();
			System.out.println(text);
		}
		
		System.out.println("Using for-each loop:");
		
		//Internally implements Iterator interface:
		for (String alphabet : alphabets) {
			System.out.println(alphabet);
		}
	}
}
package com.me.client;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrDemo2 {

	public static void main(String[] args) {
		ArrayList<Double> temperatures = new ArrayList<Double>();
		
		temperatures.add(12D);
		temperatures.add(24D);
		temperatures.add(88D);
		temperatures.add(101D);
		
		System.out.println(temperatures);
		
		System.out.println("Using for-each loop:");
		for (Double temperature : temperatures) {
			System.out.println(temperature);
		}
		
		Iterator<Double>itr = temperatures.iterator();
		/*
		 * hasNext()
		 * next()
		 * remove()
		 */
		System.out.println("Using Iterator:");
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		System.out.println("Using simple for loop:");
		
		for (int i = 0; i < temperatures.size(); i++) {
			System.out.println(temperatures.get(i));
		}
	}
}
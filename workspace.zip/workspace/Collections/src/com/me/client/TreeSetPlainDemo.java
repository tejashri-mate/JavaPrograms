package com.me.client;

import java.util.TreeSet;

public class TreeSetPlainDemo {

	public static void main(String[] args) {
		TreeSet<Integer>sortedNumbers = new TreeSet<Integer>();
		
		sortedNumbers.add(99);
		sortedNumbers.add(2);
		sortedNumbers.add(89);
		sortedNumbers.add(56);
		sortedNumbers.add(39);
		sortedNumbers.add(62);
		
		System.out.println(sortedNumbers);
	}
}
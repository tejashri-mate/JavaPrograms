package com.me.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class NewArrayListProg {

	public static void main(String[] args) {
		List<Integer>numbers = new ArrayList<>();
		
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		System.out.println(numbers);
		
		numbers.remove(1);
		System.out.println(numbers);
		
		numbers.remove(new Integer(200));
		System.out.println(numbers);
		
		numbers.add(100);
		numbers.add(200);
		
		Iterator<Integer>itr = numbers.iterator();
		ListIterator<Integer>ltr = numbers.listIterator();
		
		System.out.println("Using Iterator:");
		
		while(itr.hasNext()){
			Integer number = itr.next();
			System.out.println(number);
			
			/*if(number == 200){
				itr.remove();
			}*/
			//numbers.add(90);// Adding elements while using iterator is not allowed.
		}
		
		System.out.println("ArrayList after going through iterator:");
		System.out.println(numbers);
		
		while(ltr.hasNext()){
			Integer number = ltr.next();
			System.out.println(number);
			ltr.add(90);// Adding elements while using list iterator is allowed.
		}
		
		System.out.println("ArrayList after going through list iterator:");
		
		System.out.println(numbers);
	}
}
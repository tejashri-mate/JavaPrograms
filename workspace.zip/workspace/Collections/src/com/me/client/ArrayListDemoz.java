package com.me.client;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListDemoz {

	public static void main(String[] args) {
		ArrayList<Double>temperatures = new ArrayList<Double>();
		
		temperatures.add(10.98);
		temperatures.add(78.67);
		temperatures.add(76.56);
		
		ListIterator<Double>listItr = temperatures.listIterator();
		
		System.out.println("Going in forward direction:");
		
		while(listItr.hasNext()){
			System.out.println(listItr.next());
		}
		
		System.out.println("Going in reverse direction:");
		
		while(listItr.hasPrevious()){
			System.out.println(listItr.previous());
		}
	}
}
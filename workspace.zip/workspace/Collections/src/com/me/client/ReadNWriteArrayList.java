package com.me.client;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.me.entity.Employee;

public class ReadNWriteArrayList {

	public static void main(String[] args) {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		
		
		ArrayList<Employee>employees = new ArrayList<Employee>();
		
		Employee employee = new Employee(1, "abc", 90000);
		Employee employee1 = new Employee(2, "xyz", 100000);
		
		Employee temp = null;
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee);
		
		//Writing
		try{
			fos = new FileOutputStream("employees.ser");
			oos = new ObjectOutputStream(fos);
			
			oos.writeObject(employees);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}
		
		//Reading
		
		try{
			fis = new FileInputStream("employees.ser");
			ois = new ObjectInputStream(fis);
			
			employees = (ArrayList<Employee>)ois.readObject();
			
			int length = employees.size();
			
			for(int i = 0 ; i < length; i++){
				temp = employees.get(i);
				
				if(temp.getSalary() == 100000){
					temp.setSalary(110000);
					employees.set(i, temp);
				}
			}
		}catch(ClassNotFoundException ioe){
			System.out.println(ioe.getMessage());
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(ois != null){
					ois.close();
				}
				
				try{
					if(oos != null){
						oos.close();
					}
				}catch(IOException ioe){
					System.out.println(ioe.getMessage());
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
		//Writing again
		
		try{
			fos = new FileOutputStream("employees.ser");
			oos = new ObjectOutputStream(fos);
			
			oos.writeObject(employees);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
				try{
					if(oos != null){
						oos.close();
					}
				}catch(IOException ioe){
					System.out.println(ioe.getMessage());
				}
			}
		
		//Reading again
		
		try{
			fis = new FileInputStream("employees.ser");
			ois = new ObjectInputStream(fis);
			
			employees = (ArrayList<Employee>)ois.readObject();
			
			System.out.println(employees);
		}catch(ClassNotFoundException ioe){
			System.out.println(ioe.getMessage());
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(ois != null){
					ois.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
}
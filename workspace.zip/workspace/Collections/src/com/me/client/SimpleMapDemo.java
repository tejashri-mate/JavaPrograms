package com.me.client;

import java.util.Collection;
import java.util.Set;
import java.util.TreeMap;

public class SimpleMapDemo {

	public static void main(String[] args) {
		TreeMap<Integer, Float>students = new TreeMap<Integer, Float>();
		
		students.put(1, 90f);
		students.put(7, 56.34f);
		students.put(2, 90.77f);
		students.put(6, 78.56f);
		
		
		System.out.println("Percentage: " + students.get(6));
		
		Set<Integer>rollNos = students.keySet();
		
		for (Integer rollno : rollNos) {
			System.out.println("Roll no. " + rollno + " has " + 
		students.get(rollno) + " percent.");
		}
		
		Collection<Float>values = students.values();
		System.out.println("Only percentages:");
		for (Float value : values) {
			System.out.println(value);
		}
	}
}
package com.me.client;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrDemo {

	public static void main(String[] args) {
		ArrayList<Double> temperatures = new ArrayList<Double>();
		double temperature = 0.0;
		int index = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Enter a number. -999 to stop:");
		temperature = scInput.nextDouble();
		
		while(temperature != -999){	
			temperatures.add(temperature);
			temperature = scInput.nextDouble();
		}
		
		System.out.println("Which index no. do you want?");
		index = scInput.nextInt();
		
		if(temperatures.size() > index){
			temperature = temperatures.get(index);
			System.out.println("The temperature at given index is: " + temperature);
		}else{
			System.out.println("Such index does not exist!");
		}
		scInput.close();
	}
}
package com.me.client;

import java.util.ArrayList;
import java.util.Collections;

import com.me.entity.DscEmpid;
import com.me.entity.Employee;

public class SortArrayList {

	public static void main(String[] args) {
		ArrayList<Employee>employees = new ArrayList<Employee>();
		
		Employee employee = new Employee(1, "abc", 90000);
		Employee employee1 = new Employee(2, "xyz", 100000);
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee);
		
		//Iterator<Employee>empTraverse = employees.iterator();
		System.out.println("Printing before sorting:");
		System.out.println(employees);
		
		Collections.sort(employees, new DscEmpid());
		
		System.out.println("Printing after sorting:");
		System.out.println(employees);
	}
}
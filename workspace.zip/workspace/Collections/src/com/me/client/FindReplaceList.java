package com.me.client;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class FindReplaceList {

	public static void main(String[] args) {
		List<Integer>numbers = new LinkedList<>();
		Scanner scInput = new Scanner(System.in);
		int tobefound = 0;
		int replacement = 0;
		
		numbers.add(76);
		numbers.add(10);
		numbers.add(78);
		numbers.add(55);
		numbers.add(27);
		
		System.out.print("Which number do you wish to find? ");
		tobefound = Integer.parseInt(scInput.nextLine());
		
		System.out.print("What is the replacement? ");
		replacement = Integer.parseInt(scInput.nextLine());
		
		for (int i = 0; i < numbers.size() ; i++) {
			int no = numbers.get(i);
			
			if(no == tobefound){
				numbers.set(i, replacement);
			}
		}
		
		System.out.println(numbers);
		scInput.close();
	}
}
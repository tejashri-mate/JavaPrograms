package com.me.client;

import java.util.Set;
import java.util.TreeSet;

import com.me.entity.Emp;

public class HashSetEmployeeDemo {

	public static void main(String[] args) {
		//Set<Emp>employees = new HashSet<Emp>(5,0.75f);
		Set<Emp>employees = new TreeSet<Emp>();
		
		Emp employeeOne = new Emp(2, "abc", 90000);
		Emp employeeTwo = new Emp(1, "xyz", 100000);
		Emp employeeThree = new Emp(1, "abc", 90000);
		
		employees.add(employeeOne);
		employees.add(employeeTwo);
		employees.add(employeeThree);
		
		//if(employeeOne.equals(employeeOne))
		System.out.println(employees);
	}
}
package com.me.client;
import java.util.ArrayList;
import java.util.List;

import com.me.entity.Emp;

public class ClientEmployee {
	public static void main(String[] args) {
		List<Emp>employees = new ArrayList<>();
		
		Emp employee = new Emp(1,"abc",90000);
		Emp employee1 = new Emp(2,"xyz",100000);
		Emp employee2 = new Emp(1,"abc",90000);
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		for(Emp empl : employees){
			System.out.println(empl);
		}
	}
}
package com.me.client;

import java.util.TreeSet;

import com.me.entity.DscEmpid;
import com.me.entity.Emp;
import com.me.entity.Employee;

public class TreeSetDemo {

	public static void main(String[] args) {
		
		/*class DescEmpidSorter implements Comparator<Employee>{
			public int compare(Employee o1, Employee o2) {
				return o2.getEmpid() - o1.getEmpid();
			}
		}*/
				
		TreeSet<Emp>employees = new TreeSet<>();
		
		Emp employee = new Emp(1,"abc",90000);
		Emp employee2 = new Emp(3,"abc",80000);
		Emp employee1 = new Emp(2,"xyz",95000);
		
		employees.add(employee2);
		employees.add(employee1);
		employees.add(employee);
		
		System.out.println("Ascending order of salary:");
		for(Emp empl : employees){
			System.out.println(empl);
		}
		
		/*employees = new TreeSet<>(new Comparator<Employee>(){
			public int compare(Employee o1, Employee o2) {
				return o1.getEmpid() - o2.getEmpid();
			}
		});
		*/
		System.out.println("Ascending order of empid:");
		employees.add(employee2);
		employees.add(employee1);
		employees.add(employee);
		
		for(Emp empl : employees){
			System.out.println(empl);
		}
		
		//Descending order of Names
		employees = new TreeSet<Emp>(new DscEmpid());
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		System.out.println("\n\nDescending order of empid:");
		for(Emp empl : employees){
			System.out.println(empl);
		}
	}
}
package com.me.client;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		LinkedHashSet<Integer>naturalNumbers = new LinkedHashSet<Integer>();
		
		System.out.println(naturalNumbers.add(10));
		System.out.println(naturalNumbers.add(20));
		System.out.println(naturalNumbers.add(30));
		System.out.println(naturalNumbers.add(10));
		System.out.println(naturalNumbers.add(88));
		System.out.println(naturalNumbers.add(56));
		System.out.println(naturalNumbers.add(77));
		
		System.out.println(naturalNumbers);
		
		Iterator<Integer>itr = naturalNumbers.iterator();
		
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}
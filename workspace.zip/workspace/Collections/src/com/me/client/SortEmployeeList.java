package com.me.client;

import java.util.ArrayList;

import com.me.entity.AscEmpid;
import com.me.entity.Employee;

public class SortEmployeeList {

	public static void main(String[] args) {
		ArrayList<Employee>employees = new ArrayList<>();
		
		Employee employee = new Employee(1, "abc", 90000);
		Employee employeeOne = new Employee(2, "xyz", 100000);
		Employee employeeTwo = new Employee(5, "pqr", 120000);
		
		employees.add(employeeTwo);
		employees.add(employeeOne);
		employees.add(employee);
		
		
		System.out.println("Printing before sorting:");
		System.out.println(employees);
		
		employees.sort(new AscEmpid());
		
		System.out.println("Printing after sorting:");
		System.out.println(employees);
	}
}
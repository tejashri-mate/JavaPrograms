package com.me.client;

import com.me.entity.Employee;

public class InnerDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(1, "bvk", 90000,"Pune","Maharashtra");
		System.out.println(employee);
	}
}
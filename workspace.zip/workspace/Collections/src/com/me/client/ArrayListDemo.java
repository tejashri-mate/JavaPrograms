package com.me.client;
import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<>();//default size: 10
		
		//numbers.add("welcome");
		//Above lines are not recommended approach.
		numbers.add(99);
		numbers.add(100);
		numbers.add(200);
		numbers.add(100);
		
		System.out.println(numbers);
		
		numbers.remove(3);
		
		int size = numbers.size();
		
		System.out.println("Using simple for loop:");
		for(int i = 0 ; i < size ; i++){
			System.out.println(numbers.get(i));//calling get is not best practise
		}
	}
}
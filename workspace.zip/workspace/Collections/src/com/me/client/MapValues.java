package com.me.client;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, Float>studRecords = new HashMap<Integer, Float>();
		
		Scanner scInput = new Scanner(System.in);
		
		int rollno = 0;
		float percent = 0.0f;
		
		while(true){
			System.out.print("Enter Roll no. Enter -999 to stop: ");
			rollno = scInput.nextInt();
				     scInput.nextLine();
			
		    if(rollno != -999){
			System.out.print("Enter Percentage: ");
			percent = scInput.nextFloat();
				  	  scInput.nextLine();
					  	  
			studRecords.put(rollno, percent);		    	
		    }else{
		    	break;
		    }
		}
		
		Collection<Float>percentages = (Collection<Float>)studRecords.values();
		
		System.out.println("Only Percentages:");
		
		for(Float percentage : percentages){
			System.out.println(percentage);
		}
		scInput.close();
	}
}
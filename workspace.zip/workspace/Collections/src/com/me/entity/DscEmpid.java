package com.me.entity;

import java.util.Comparator;

public class DscEmpid implements Comparator<Emp> {
	public int compare(Emp o1, Emp o2) {
		return o2.getEmpid() - o1.getEmpid();
	}
}
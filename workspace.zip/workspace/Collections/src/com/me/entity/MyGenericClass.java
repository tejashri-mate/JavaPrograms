package com.me.entity;

public class MyGenericClass<T> {
	public void print(T parameter){
		System.out.println(parameter);
	}
}
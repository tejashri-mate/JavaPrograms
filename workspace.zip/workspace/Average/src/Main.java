import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		double overs,current,target;
		System.out.println("Enter the number of overs bowled so far");
		overs=sc.nextDouble();
		System.out.println("Enter the current run rate");
		current=sc.nextDouble();
		System.out.println("Enter the target score");
		target=sc.nextDouble();
		double remaning=50-overs;
		double req=(target-(current*overs))/(remaning);
		System.out.println("Required run rate is "+String.format("%.2f", req));
	}

}

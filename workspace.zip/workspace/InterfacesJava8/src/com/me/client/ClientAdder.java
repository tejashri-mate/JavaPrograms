package com.me.client;

import com.me.entity.Adder;

public class ClientAdder {

	public static void main(String[] args) {
		Adder adder = new Adder();
		
		int sum = adder.addIt(10);
		System.out.println(sum);
		
		sum = adder.addIt(10,20,30);
		System.out.println(sum);
	}
}
package com.me.client;

import com.me.entity.Circle;
import com.me.entity.IShape;
import com.me.entity.Rectangle;

public class ClientShape {
	public static void main(String[] args) {
		/*IShape shape = new Rectangle(10,10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);
		
		shape = new Circle(10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);*/
		
		Rectangle rectangle = new Rectangle(10, 15);
		Circle circle = new Circle(10);
		
		IShape shapes[] = {rectangle,circle};
		
		for(int i = 0 ; i < shapes.length ; i++){
			shapes[i].calcArea();
			shapes[i].calcPerimeter();
			System.out.println(shapes[i]);
		}
		/*IShape shape = new Rectangle(10,10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);
		
		shape = new Circle(10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);*/
		
		/*Rectangle rectangle = new Rectangle(10,10);
		rectangle.calcArea();
		rectangle.calcPerimeter();
		System.out.println(rectangle);
		
		Circle circle = new Circle(10);
		circle.calcArea();
		circle.calcPerimeter();
		System.out.println(circle);*/
	}
}
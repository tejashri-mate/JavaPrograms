package com.me.entity;

public class Lodge4 implements IFoodService, IRoomService, ITaxiService {

	@Override
	public void calcTaxiService() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcFoodBill() {
		// TODO Auto-generated method stub

	}

}

package com.me.entity;

public class C extends BAdapter {
	@Override
	public void methodB(){
		System.out.println("Inside method B");
	}
}
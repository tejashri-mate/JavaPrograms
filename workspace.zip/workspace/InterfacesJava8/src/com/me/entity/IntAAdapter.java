package com.me.entity;

public class IntAAdapter implements IntA {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodC() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodD() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodE() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodF() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodG() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodH() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodI() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodJ() {
		// TODO Auto-generated method stub

	}

}

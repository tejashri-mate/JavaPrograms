package com.me.entity;

public class IntAJava8Impl implements IntAJava8 {

}
package com.me.entity;

public class FinalA extends AdapterA {

	@Override
	public void methodC() {
		// TODO Auto-generated method stub
		super.methodC();
		System.out.println("Implementing method C");
	}

	
}
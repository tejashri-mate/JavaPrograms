package com.me.entity;

public interface IBestLodge extends IRoomService, IFoodService, IVehicleService {

}
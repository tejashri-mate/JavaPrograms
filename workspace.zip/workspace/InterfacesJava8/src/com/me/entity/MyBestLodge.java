package com.me.entity;

public class MyBestLodge implements IBestLodge {

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcFoodBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcTaxiBill() {
		// TODO Auto-generated method stub

	}

}
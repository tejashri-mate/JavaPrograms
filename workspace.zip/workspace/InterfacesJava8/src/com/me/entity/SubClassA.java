package com.me.entity;

public class SubClassA extends AImpl {
	public void methodE(){
		System.out.println("In MethodE()");
	}
}
package com.me.entity;

public class BeIt implements IStudent {

	@Override
	public int calculateTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

}

package com.me.entity;

public class ChildOfIntA extends IntAAdapter {
	@Override
	public void methodD(){
		System.out.println("Inside methodD()");
	}
}
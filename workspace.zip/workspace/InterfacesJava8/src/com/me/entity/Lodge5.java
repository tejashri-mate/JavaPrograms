package com.me.entity;

public class Lodge5 implements IMasterLodge {

	@Override
	public void calcTaxiService() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcFoodBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
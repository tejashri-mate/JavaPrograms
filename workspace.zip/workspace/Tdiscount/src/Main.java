import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Float x,y,z;
		System.out.println("Price of item 1 :");
		x=sc.nextFloat();
		System.out.println("Price of item 2 :");
		y=sc.nextFloat();
		System.out.println("Discount in percentage :");
		z=sc.nextFloat();
		float total=x+y;
		double discount=(total-(total*z/100));
		double saved=total-discount;
		System.out.println("Total amount : $"+String.format("%.2f", total));
		System.out.println("Discounted amount : $"+String.format("%.2f", discount));
		System.out.println("Saved amount : $"+String.format("%.2f", saved));
		

	}

}

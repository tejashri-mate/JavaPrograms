package com.cognizant.client;

public class EmployeeClient {
	public static void main(String[] args)
	{
		Set<Employee> Employees= new HashSet<Employee>();
		Employee emp=new Empolyee();
		emp.input();
		Employee
	}
	
}

package com.cognizant.entity;
import java.util.*;
public class EmployeeEmail {
	private String name;
	private String surname;
	
	public EmployeeEmail(String name,String surname){
		this.name=name;
		this.surname=surname;
	}
	
	public void input(){
		Scanner sc=new Scanner(System.in); 
		System.out.println("enter name");
		name=sc.nextLine();
		System.out.println("enter surname");
		surname=sc.nextLine();
	}
 
	@Override
	public String toString() {
		return "EmployeeEmail [name=" + name + ", surname=" + surname + "]";
	}
}

import java.util.Scanner;
import java.lang.Math;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		double x,y,k;
		int z;
		System.out.println("Enter the X and Y coordinate of friend's house");
		x=sc.nextDouble();
		y=sc.nextDouble();
		k=Math.sqrt((x-3)*2+(y-4)*2);
		z=(int)Math.ceil(k);
		System.out.println("Raju needs "+z+" jumps");
	}

}

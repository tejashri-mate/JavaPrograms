import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		//char a;
		//a=input.nextLine().charAt(0);s
		String a;
		a=sc.nextLine();
		System.out.println("Harry has to pick the flag that has "+a+" in it");
		


	}

}

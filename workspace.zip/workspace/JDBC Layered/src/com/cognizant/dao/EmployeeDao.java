package com.cognizant.dao;

import java.util.List;

import com.cognizant.exception.EmployeeException;
import com.cognizant.model.Employee;

public interface EmployeeDao {
	int insertEmployee(Employee employee) throws EmployeeException;
	int updateEmployee(Employee employee) throws EmployeeException;
	int deleteEmployee(Employee employee) throws EmployeeException;
	List<Employee> viewEmployee() throws EmployeeException;
	
}

package com.cognizant.dao;

import java.sql.Connection;
import java.util.List;

import com.cognizant.exception.EmployeeException;
import com.cognizant.helper.DBUtil;
import com.cognizant.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public int insertEmployee(Employee employee) throws EmployeeException {
		String sql="INSERT INTO emp1 VALUES(?,?,?)";
		
		try{
			Connection connEmployee=DBUtil.createConnection();
				PreparedStatement pstEmployee = connEmployee.prepareStatement(sql);)
		}
		return 0;
	}

	@Override
	public int updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Employee> viewEmployee() throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}

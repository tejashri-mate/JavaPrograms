package com.cognizant.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connStudent;

	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle reMysql = ResourceBundle.getBundle("oracle");

		String url = reMysql.getString("url");
		String username = reMysql.getString("username");
		String password = reMysql.getString("password");
		String driver = reMysql.getString("driver");

		Class.forName(driver);

		connStudent = DriverManager.getConnection(url, username, password);

		return connStudent;
	}

	public static void closeConnection() throws SQLException {
		connStudent.close();
	}
}
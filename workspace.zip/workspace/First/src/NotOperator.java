
public class NotOperator {

	public static void main(String[] args) {
		int number = 10;
		int another = 15;
		
		if(!(number == 20 && another == 25)){//To reverse this condition, use ! operator.
			System.out.println("Correct!");
		}else{
			System.out.println("Incorrect!");
		}
	}
}
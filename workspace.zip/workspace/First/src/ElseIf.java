import java.util.Scanner;

public class ElseIf {

	public static void main(String[] args) {
		int qty1 = 0;
		int qty2 = 0;
		int qty3 = 0;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter three numbers, separated by spaces: ");
		qty1 = scInput.nextInt();
		qty2 = scInput.nextInt();
		qty3 = scInput.nextInt();
		
		if(qty1 > qty2 && qty1 > qty3)
		{
			System.out.println(qty1 + " is greatest.");
		}
		
		else if(qty2 > qty3 && qty2 > qty1)
		{
			System.out.println(qty2 + " is greatest.");
		}
		
		else
		{
			System.out.println(qty3 + " is greatest.");
		}
		
		scInput.close();
	}
}
import java.util.Scanner;

public class InputElements {

	public static void main(String[] args) {
		double radius;
		double height;
		double volume;
		final double PI = 3.14;
		//This will help us to read text & convert it to correct data type.
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter radius: ");
		radius = scInput.nextDouble();
		
		System.out.print("Enter height: ");
		height = scInput.nextDouble();
		
		volume = PI * radius * radius * height;
		
		System.out.printf("Volume of Cylinder: %-10.2f",volume);
		
		scInput.close();
	}
}
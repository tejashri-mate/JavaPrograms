import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		int arr[] = {44,3,63,15,77,56};
		int number = 0;
		int index = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter number to be searched: ");
		number = scInput.nextInt();
		
		for(int i = 0 ; i < arr.length ; i++){
			if(number == arr[i]){
				index = i;
				break;
			}
		}
		
		if(index < 0){
			System.out.println("Number not found.");
		}else{
			System.out.println("Number found at position " + index);
		}
		
		scInput.close();
	}
}
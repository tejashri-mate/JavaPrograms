
public class IfDemo {

	public static void main(String[] args) {
		int number1 = 0;
		boolean isItTrue = true;
		
		//if statement requires a boolean value.
		if(isItTrue){//if number1 is nonzero.
			
		}
	}
}
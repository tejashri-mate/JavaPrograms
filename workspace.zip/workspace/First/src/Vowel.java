public class Vowel {

	public static void main(String[] args) {
		char ch = 'o';
		
		switch(ch){
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
			System.out.println("Vowel.");
			break;
		default:
			System.out.println("Not a vowel.");
			break;			
		}
	}
}
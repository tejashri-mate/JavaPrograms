
public class ConditionInC {

	public static void main(String[] args) {
		int a = 10;
		boolean isIt = true;
		if(isIt){// if a is nonzero
			System.out.println("Not allowed in Java");
		}
	}
}

public class BitwiseAndInCondition {

	public static void main(String[] args) {
		int x = -12;
		int y = 3;
		int res=x>>>y;
		/*if(x == 3 ^ y++ == 5){
			System.out.println("Correct!");
		}else{
			System.out.println("Incorrect!");
		}
		*/
		System.out.println(res);
	}
}
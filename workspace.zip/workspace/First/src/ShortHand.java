
public class ShortHand {

	public static void main(String[] args) {
		int number = 10;
		System.out.println(number);
		
		number += 5;//number = number + 5;
		System.out.println(number);
	}
}
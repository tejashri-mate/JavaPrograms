
public class ArraysDemo {
	public static void main(String[] args) {
		/*int a[];
		int []b;
		int[] c;*/
		
		//a = new int[5];
		
			
		int a[] = {1,34,56,31};//Cannot be done after declaration is over.
		int []b;
		int[] c;
		
		//a = new int[5];//Method 1 of defining array
		
		//a = new int[] {1,34,56,31};//Method 2 of defining array
		
		//a = {1,34,56,31};//Not permissible. Allowed only at declaration.
		System.out.println("Using simple for loop:");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		System.out.println("Using for each loop:");
		for (int i : a) {// for-each loop or enhanced for loop
			System.out.println(i);
		}
	}
}
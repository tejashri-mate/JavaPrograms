
public class BitwiseExOr {

	public static void main(String[] args) {
		int number = 2;//0000 0010
		int shift = 3; //0000 0011
		//				 0000 0001
		
		int result = number ^ shift;

		System.out.println(result);
	}
}

public class OnesCompliment {

	public static void main(String[] args) {
		int number = 3;
		int onesCompliment = ~number;
		
		System.out.println(number);
		System.out.println(onesCompliment);

	}

}

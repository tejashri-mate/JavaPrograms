import java.util.Scanner;

public class InputDobArr {

	public static void main(String[] args) {
		int a[][] = new int[3][4];//3 rows & 4 columns.
		
		Scanner scInput = new Scanner(System.in);
		
		for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print("Enter an element: ");
				a[row][col] = scInput.nextInt();
			}
			System.out.println();
		}
		
		System.out.println("The inputted array is: ");
		
		for (int row = 0; row < a.length; row++) {
			for(int col = 0 ; col < a[row].length;col++){
				System.out.print(a[row][col]+"\t");
			}
			System.out.println();
		}
		scInput.close();
	}
}
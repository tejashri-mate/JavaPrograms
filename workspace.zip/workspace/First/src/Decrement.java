
public class Decrement {

	public static void main(String[] args) {
		int number = 10;
		int target = 0;
		
		System.out.println("Before decrement: ");
		System.out.println("Number: "+number);
		System.out.println("Target: "+target);
		
		
		target = number--;//value is assigned first, then incremented.
		System.out.println("After post decrement: ");
		System.out.println("Number: "+number);
		System.out.println("Target: "+target);
		
		target = --number;//value is incremented first, then assigned.
		System.out.println("After pre decrement: ");
		System.out.println("Number: "+number);
		System.out.println("Target: "+target);
	}
}
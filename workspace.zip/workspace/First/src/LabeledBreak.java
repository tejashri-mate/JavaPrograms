
public class LabeledBreak {

	public static void main(String[] args) {
		// i++ or ++i is same, when there is nothing on left hand side.
		// but if a = i++, it is post inc., a = ++i is pre inc.
		pizza_shop:
		{
		for(int i = 1 ; i <= 3 ; i++){
			for(int j = 1 ; j <= 4 ; j++){
				if(i == 2 && j == 2){
					break pizza_shop;
				}
				System.out.println(i+"\t"+j);
			}
			System.out.println("\nOutside inner loop\n");
		}
		System.out.println("Outside both the loops.");
		}
		System.out.println("Outside block.");
	}
}
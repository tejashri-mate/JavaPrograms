import java.util.Scanner;

public class AndOperator {

	public static void main(String[] args) {
	int age = 0;
	int experience = 0;
	
	Scanner scInput = new Scanner(System.in);
	
	System.out.print("Enter age: ");
	age = scInput.nextInt();
	
	System.out.print("Enter experience: ");
	experience = scInput.nextInt();
	
	if(age >= 30 && experience >= 5){
		System.out.println("You are selected for job.");
	}else{
		System.out.println("Hard luck! Better luck next time!!");
	}
	
	scInput.close();
	}
}
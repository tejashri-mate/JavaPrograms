package com.bvk.entity;

import java.util.Scanner;

public final class BA extends AbstractStudent {
	private int history;
	private int geography;
	private int eco;
	
	@Override
	public void input() {
		super.input();
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter history: ");
		history = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter geography: ");
		geography = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter Eco: ");
		eco = Integer.parseInt(scInput.nextLine());
	}

	@Override //Annotation. It is a comment for JVM & not the developer.
	public void calculateTotal() {
		this.total = this.history + this.geography + this.eco;
		calculatePercent();
	}

	@Override
	public void calculatePercent() {
		this.percent = this.total/3.0f;
	}

	@Override
	public String toString() {
		return "BA [history=" + history + ", geography=" + geography + ", eco=" + eco + 
				", total="+getTotal()+", percent="+getPercent()
				 + "]";
	}
}
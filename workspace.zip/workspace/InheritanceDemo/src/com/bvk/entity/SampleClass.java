package com.bvk.entity;

public final class SampleClass {
	public void methodA(){
		
	}
	
	public void methodB(){
		
	}
}
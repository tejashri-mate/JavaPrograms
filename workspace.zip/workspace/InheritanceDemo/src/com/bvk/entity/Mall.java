package com.bvk.entity;

public class Mall extends Shop {//Shop is parent class of Mall.
	//Mall is child class of Shop.
	//Shop is a super class. Mall is a subclass.
	//Variables from Shop are available here. Not accessible directly.
	//Available through public members (methods) of the class.
	
	private float exportImportTax;

	public Mall() {
		super();
		System.out.println("Inside same class constructor");
	}

	public Mall(int shopId, String name, float profit, float tax, float exportImportTax) {
		//this();
		super(shopId, name, profit, tax);
		//super();//automatically done when no super class constructor called.
		this.exportImportTax = exportImportTax;
	}

	public float getExportImportTax() {
		return exportImportTax;
	}

	public void setExportImportTax(float exportImportTax) {
		this.exportImportTax = exportImportTax;
	}
	
	//Polymorphism
	/*
	 * One Name i.e. calculate & Many forms. One method is in Parent.
	 * Another is in Child.
	 */
	@Override
	public void calculate(){
		super.calculate();//Call to parent class method.
		this.profitAfterTax -= this.exportImportTax;
		
		/*float pat = getProfitAfterTax();
		pat -= this.exportImportTax;
		setProfitAfterTax(pat);*/
	}
	
	/*@Override
	public void output(){
		super.output();//Call to parent class method.
		System.out.println("Export Import Tax: " + this.exportImportTax);
	}*/
	
	public void printInDetail(){
		System.out.println("Printing all details.");
	}
	
	@Override
	public String toString(){
		String text = "Shop ID: " + getShopId() + "\n" +
				  "Shop Name: " + getName() + "\n" +
				  "Profit: " + getProfit() + "\n" +
				  "Tax: " + getTax() + "\n" +
				  "Export Import Tax: " + this.exportImportTax + "\n" +
				  "Profit After Tax: " + getProfitAfterTax() + "\n" +
				  "==========================================";
	
	return text;
	}
}
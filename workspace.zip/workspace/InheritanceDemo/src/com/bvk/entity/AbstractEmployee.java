package com.bvk.entity;

public abstract class AbstractEmployee {
	public abstract void calculateSalary();
}
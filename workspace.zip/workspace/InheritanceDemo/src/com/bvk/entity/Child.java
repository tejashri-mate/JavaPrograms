package com.bvk.entity;

public class Child extends SampleClass {

}
package com.bvk.entity;

public class D extends A {
	
	@Override
	public void output(){
		
	}
}
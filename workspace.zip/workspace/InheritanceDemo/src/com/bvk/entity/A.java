package com.bvk.entity;

public class A {
	int a;
	int b;
	
	public void output(){
		System.out.println("a: " + a);
		System.out.println("b: " + b);
	}
}
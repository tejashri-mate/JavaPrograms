package com.bvk.client;

import com.bvk.entity.A;

public class C {

	public static void main(String[] args) {
		A a = new A();
		
		a.a = 10;
		a.b = 20;
		
		
	}
}
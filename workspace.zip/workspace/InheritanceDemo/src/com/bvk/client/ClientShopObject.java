package com.bvk.client;

import com.bvk.entity.Mall;
import com.bvk.entity.Shop;

public class ClientShopObject {
	public static void main(String[] args) {
		//Storing object of child type in parent reference variable.
		Shop shop = new Mall(1, "abc mall", 500000, 5000, 5000);//Upcasting
		shop.calculate();//Mall
		//shop.printInDetail();//Not possible as Shop knows only common part.
		//printInDetail is an exclusive method of Mall. Not inherited from
		//Shop.
		shop.output();//Mall
		System.out.println("==========================================");

		Mall mall = (Mall)shop;//Downcasting
		mall.output();
		System.out.println("==========================================");
		
		
		shop = new Shop(2, "xyz general stores", 600000, 5000);
		shop.calculate();//Shop
		shop.output();//Shop
		System.out.println("==========================================");
		
		mall = (Mall)shop;//We're cheating JVM assuring it object of Mall.
		mall.calculate();//When it executes at runtime, JVM understands cheating.
		mall.output();
	}
}
package com.bvk.client;

public class Client7 {

	public static void main(String[] args) {
		Dao dao = new Dao();
		dao.showRecords();
	}
}
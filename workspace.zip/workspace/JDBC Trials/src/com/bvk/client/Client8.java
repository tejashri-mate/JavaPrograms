package com.bvk.client;

public class Client8 {

	public static void main(String[] args) {
		Dao dao = new Dao();
		
		dao.showTableStructure();
	}
}
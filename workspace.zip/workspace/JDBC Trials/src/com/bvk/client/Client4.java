package com.bvk.client;

public class Client4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int empid = 2;
		
		Dao dao = new Dao();
		
		dao.retrieveEmployee(empid);
	}
}
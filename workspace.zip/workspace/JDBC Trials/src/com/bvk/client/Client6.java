package com.bvk.client;

public class Client6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int empid = 1;
		
		Dao dao = new Dao();
		
		dao.returnSalary(empid);
	}
}
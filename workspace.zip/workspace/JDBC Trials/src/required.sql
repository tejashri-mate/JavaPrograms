CREATE TABLE emp1(
  empid INT PRIMARY KEY,
  name VARCHAR2(45) NOT NULL,
  salary FLOAT NOT NULL);
  
CREATE OR REPLACE PROCEDURE getemp(p_empid INT, p_amt OUT FLOAT)
IS
  BEGIN
    SELECT salary INTO p_amt FROM emp1 WHERE empid = p_empid;
END getemp;

CREATE OR REPLACE PROCEDURE updateSalary(p_empid INT, p_amt IN OUT FLOAT)
IS
  BEGIN
    UPDATE emp1 SET salary = salary + p_amt WHERE empid = p_empid;
    SELECT salary INTO p_amt FROM emp1 WHERE empid = p_empid;
END updateSalary;

CREATE OR REPLACE PROCEDURE insertit(p_empid INT, p_name IN CHAR, p_salary FLOAT)
IS
  BEGIN
    INSERT INTO emp1 VALUES(p_empid, p_name, p_salary);
END insertit;

CREATE OR REPLACE FUNCTION getsal(p_empid INT)
RETURN FLOAT
IS
v_salary FLOAT;
BEGIN
      SELECT salary INTO v_salary FROM emp1 WHERE empid = p_empid;
      RETURN v_salary;
END getsal;
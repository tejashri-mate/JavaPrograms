import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		float a;
		System.out.println("Harry has got :");
		a=sc.nextFloat();
		System.out.printf("Prof.Dumbledore must get the wand worth $%.2f.",a);
		



	}

}

package programs;

public class StringMethods1 {

	public static void main(String[] args) {
		String text = "You can fool some people all the time,\n"+
					  "You can fool all people for some time,\n"+
					  "But you cannot fool all people all time.";
		
		int index = text.indexOf('f');
		System.out.println(index);
		
		index = text.indexOf('f',index+1);
		System.out.println(index);
		
		index = text.indexOf("some");
		System.out.println(index);
		
		index = text.indexOf("some",index+1);
		System.out.println(index);
		
		int lastIndexOf = text.lastIndexOf('a');
		System.out.println("Last index of a: " + lastIndexOf);
		
		lastIndexOf = text.lastIndexOf('a',lastIndexOf-1);
		System.out.println("Last index of a: " + lastIndexOf);
		
		lastIndexOf = text.lastIndexOf("all");
		System.out.println("Last index of a: " + lastIndexOf);
		
		lastIndexOf = text.lastIndexOf("all",index-1);
		System.out.println("Last index of a: " + lastIndexOf);
	}
}
package programs;

public class StringConstantPool {
	public static void main(String[] args) {
		String str = new String("Whats App");//Heap
		String str1 = "Whats App";//String Constant Pool
		
		if(str == str1){//Two separate objects, two separate references.
			System.out.println("Same");
		}else{
			System.out.println("Not Same");
		}
		
		if(str.equals(str1)){
			System.out.println("Same");
		}else{
			System.out.println("Not same");
		}
		
		String str2 = "Whats App";
		
		System.out.println("\nInside String Constant Pool:");
		if(str1 == str2){
			System.out.println("Same");
		}else{
			System.out.println("Not same");
		}
		
		if(str2.equals(str1)){
			System.out.println("Same");
		}else{
			System.out.println("Not same");
		}
		
		String str3 = "Whats "+"App";
		
		if(str1 == str2 && str2 == str3){
			System.out.println("All three are Same");
		}else{
			System.out.println("Not same");
		}
		
		if(str2.equals(str1) && str3.equals(str1)){
			System.out.println("All three are Same");
		}else{
			System.out.println("Not same");
		}
		
		str = str.intern();//Put the heap object into String Constant Pool.
		
		System.out.println("After transferring the object from heap:");
		if(str == str1){
			System.out.println("Same");
		}else{
			System.out.println("Not same");
		}
		
		if(str.equals(str1)){
			System.out.println("Same");
		}else{
			System.out.println("Not same");
		}
	}
}
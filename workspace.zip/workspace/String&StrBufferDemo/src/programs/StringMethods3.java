package programs;

public class StringMethods3 {
	public static void main(String[] args) {
		String str = new String("naresh it");
		
		String newStr = str + " is best in online training.";
		System.out.println(newStr);
		
		newStr = "Java Jives".replace('J', 'W');
		System.out.println(newStr);
		
		newStr = new String("    Hello Java   ");
		System.out.println(newStr+"...");
		
		newStr = newStr.trim();
		System.out.println(newStr+"...");
	}
}
package programs;

public class WrappersDemo {

	public static void main(String[] args) {
		Integer num = new Integer(10);
		Integer num1 = new Integer("10");
		Float percent = 98.67f;
		Integer number = 10;//Autoboxing. jdk 1.5
		
		System.out.println(number);
		
		num = num1 + number;
		System.out.println(num);
		
		num = 300;
		num1 = 300;
		
		if(num == num1){
			System.out.println("They are equal.");
		}else{
			System.out.println("They are not equal.");
		}
		
		int n = num.intValue();
		System.out.println(n);
		
		long bow = num.longValue();
		System.out.println(bow);
		
		short distance = num.shortValue();
		System.out.println(distance);
		
		byte ofPizza = num.byteValue();
		System.out.println(ofPizza);
		
		int number1 = num;//Unboxing.  jdk 1.5. Taking out of object & assigning it to primitive
		System.out.println(number1);
		
		float percentage = percent;
	}
}
package programs;

public class StringBufferDemo {
	public static void main(String[] args) {
		StringBuffer sbf = new StringBuffer();//Can be modified in same object.
		System.out.println(sbf.capacity());//16
		
		sbf.append("India has bright future");//Add at end
		System.out.println(sbf);
		System.out.println(sbf.length());
		System.out.println("New capacity: "+sbf.capacity());
		sbf.append(".");
		System.out.println(sbf);
		
		sbf.insert(10, "very ");
		System.out.println(sbf);
		
		sbf.delete(10, 15);
		System.out.println(sbf);
		
		sbf.deleteCharAt(sbf.length() - 1);
		System.out.println(sbf);
		
		char ch = sbf.charAt(3);
		System.out.println(ch);
		
		String sub = sbf.substring(10, 16);
		System.out.println(sub);
		
		sbf.ensureCapacity(15);//At least 15 characters can be stored.
		
		sbf.setLength(15);
		System.out.println(sbf);
		
		sbf.reverse();
		System.out.println(sbf);
	}
}
import java.util.Scanner;
import java.lang.Math;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		double x,y,z,k;
		System.out.println("Enter the sides of a triangle");
		x=sc.nextDouble();
		y=sc.nextDouble();
		z=sc.nextDouble();
		k=(x+y+z)/2;
		double rad=(Math.sqrt(k*(k-x)*(k-y)*(k-z)))/k;
		System.out.println("The radius of the circle is "+String.format("%.2f",rad));
		

	}

}

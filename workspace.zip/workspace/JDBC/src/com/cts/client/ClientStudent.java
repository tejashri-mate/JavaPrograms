package com.cts.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ClientStudent {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ResourceBundle resOracle = ResourceBundle.getBundle("oracle");

		String url = resOracle.getString("url");
		String username = resOracle.getString("username");
		String password = resOracle.getString("password");
		String driver = resOracle.getString("driver");

		Class.forName(driver);
		try(Connection studConnection = DriverManager.getConnection(url, username, password)){
		Statement stStudent = studConnection.createStatement();
		ResultSet rsStudent = null;
		ResultSetMetaData rsmd = null;
		String sql = "select id,name,percent from student";

		
			rsStudent = stStudent.executeQuery(sql);

			rsmd = rsStudent.getMetaData();

			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				System.out.print(rsmd.getColumnLabel(i));
				System.out.print("\t" + rsmd.getColumnTypeName(i));
				System.out.println("\t" + rsmd.getColumnDisplaySize(i));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		}
	}

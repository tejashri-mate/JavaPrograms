package com.cts.client;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

import com.cts.helper.DBUtil;

public class Transact {

	/**
	 * @param args
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		// TODO Auto-generated method stub
		Connection studConnection = DBUtil.createConnection();
		Statement stStudent = studConnection.createStatement();

		studConnection.setAutoCommit(false);

		String sql = "INSERT INTO emp1 VALUES(4001,'XXX', 90000)";
		String sql1 = "INSERT INTO emp1 VALUES(8000,'yyy', 90000)";

		try {
			Savepoint savePointA = studConnection.setSavepoint();
			int status = stStudent.executeUpdate(sql);

			Savepoint savePointB = studConnection.setSavepoint();
			status = stStudent.executeUpdate(sql1);

			studConnection.rollback(savePointB);
			studConnection.commit();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}

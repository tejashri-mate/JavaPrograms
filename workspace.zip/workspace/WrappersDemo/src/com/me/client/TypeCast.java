package com.me.client;

public class TypeCast {

	public static void main(String[] args) {
		byte age = 60;
		int num = 120;
		
		System.out.println(age);
		System.out.println(num);
		System.out.println();
		
		age = (byte)num;
		
		System.out.println(age);
		System.out.println(num);
		System.out.println();
		
		num = age;
		
		System.out.println(age);
		System.out.println(num);
		System.out.println();
		
		num = 10;
		age = 60;
		
		age = (byte)(age + num);
		
		System.out.println(age);
		System.out.println(num);
		System.out.println();
		
		num = 10;
		age = 60;
		
		age += num;
		
		System.out.println(age);
		System.out.println(num);
		System.out.println();		
	}
}
package com.me.client;

public class FeaturesOfInteger {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i = -128;
		Integer j = -128;
		//For range -128 to +127, results are different.
		if(i != j){
			System.out.println("Different");
		}else{
			System.out.println("Same");
		}
		
		if(i == j){
			System.out.println("Same");
		}else{
			System.out.println("Different");
		}
		//For range other than above, results are different than above.
		i = 130;
		j = 130;
		
		if(i != j){
			System.out.println("Different");
		}else{
			System.out.println("Same");
		}
		
		if(i == j){
			System.out.println("Same");
		}else{
			System.out.println("Different\n");
		}
		
		String binary = Integer.toBinaryString(-10);
		System.out.println("Binary using toBinaryString method: "+binary);

		String octal = Integer.toOctalString(10);
		System.out.println("Octal using toOctalString method: "+octal);
		
		String hex = Integer.toHexString(10);//This is also available with
		//Float & Double.
		System.out.println("Hex using toHexString with radix method: "+hex+"\n\n");
		
		binary = Integer.toString(-10, 2);
		System.out.println("Binary using toString with radix method: "+binary);
		
		octal = Integer.toString(10, 8);
		System.out.println("Octal using toString with radix method: "+ octal);
		
		hex = Integer.toString(10, 16);
		System.out.println("Hex using toString with radix method: "+ hex+"\n");
		
		String decimal = Integer.toString(10);
		System.out.println("Decimal using toString method: " + decimal);
	}
}
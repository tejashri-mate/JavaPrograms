package com.me.client;

public class Mock {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "appreciation is the best way to motivate";
		String ans = new String();
		String strs[] = str.split(" ");
		int max = 0;
		int i,j;
		for (i = 0; i < strs.length; i++) {
			int count = 0;
			
			for (j = 0; j < strs[i].length(); j++) {
				char c = strs[i].charAt(j);
				
				switch(c){
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':
				case 'A':
				case 'E':
				case 'I':
				case 'O':
				case 'U':
						count++;
						break;
				}
				
				if(count > max){
					ans = strs[i];
					max = count;
				}
			}
		}
		System.out.println(ans);
	}
}
package com.me.client;

public class MathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		int b = 20;
		double number = 4.2;
		double answer = 0.0;
		int c = Math.min(a, b);
		
		System.out.println("Minimum is: " + c);
		
		c = Math.max(a, b);
		System.out.println("Maximum is: " + c);
		
		c = -10;
		System.out.println("c: " + c);
		
		c = Math.abs(c);
		System.out.println("c: " + c);
		
		answer = Math.ceil(number);
		System.out.println(answer);
		
		answer = Math.floor(number);
		System.out.println(answer);
	}
}
package com.me.client;

public class Mock2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] str = args[0].toCharArray();
		String str1 = new String("");
	
		for(char s : str){
			switch(s){
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
			case 'A':
			case 'E':
			case 'I':
			case 'O':
			case 'U':
					 str1 += s;
			}
		}
		
		if(str1.equalsIgnoreCase("aeiou")){
			System.out.println("fufa");
		}else{
			System.out.println("nehru");
		}
	}
}
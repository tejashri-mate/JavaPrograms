package com.me.client;

public class ProofOfImmutability {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i = 1000;
		Integer j = i;
		
		if(i == j){
			System.out.println("Both point at same object.");
		}else{
			System.out.println("Both point at different objects.");
		}
		
		j++;
		// Now j is unwrapped, incremented & put in a different object than
		// in i. If it is done in the same object then i & j should be referring 
		// same object.
		if(i == j){
			System.out.println("This time both point at same object.");
		}else{
			System.out.println("This time both point at different objects.");
		}
		
		System.out.println("i: " + i);
		System.out.println("j: " + j);
	}
}
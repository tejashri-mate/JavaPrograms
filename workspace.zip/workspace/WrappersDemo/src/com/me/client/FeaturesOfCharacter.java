package com.me.client;

public class FeaturesOfCharacter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c = 't';
		char ch = 'T';
		char chr = '0';
		
		/*
		 * static boolean isLowerCase(char ch)
		   static boolean isUpperCase(char ch)
		   static boolean isTitleCase(char ch)
		   static boolean isDigit(char ch)
		   static boolean isLetter(char ch)
		   static boolean isLetterOrDigit(char ch)
		   static char toUpperCase(char ch)
		   static char toLowerCase(char ch)
		   static char toTitleCase(char ch)
		 * */
		
System.out.println("Is " + c + " lowercase? " + Character.isLowerCase(c));
System.out.println("Is " + c + " uppercase? " + Character.isUpperCase(ch));
System.out.println("Is " + ch + " titlecase? " + Character.isTitleCase(ch));
System.out.println("Is " + chr + " a digit? " + Character.isDigit(chr));
System.out.println("Is " + ch + " a letter? " + Character.isLetter(ch));
System.out.println("Is " + ch + " a letter or a digit? " + Character.isLetterOrDigit(ch));
System.out.println("Is " + chr + " a letter or a digit? " + Character.isLetterOrDigit(chr));
System.out.println("When " + c + " is converted to uppercase: " + Character.toUpperCase(c));
System.out.println("When " + ch + " is converted to lowercase: " + Character.toLowerCase(ch));
System.out.println("When " + c + " is converted to titlecase: " + Character.toTitleCase(c));
	}
}
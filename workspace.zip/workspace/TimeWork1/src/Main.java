import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		float x;
		float b,a;
		float c;
		System.out.println("Enter the value of x");
		x=sc.nextFloat();
		b=(3*x/2);
		a=b/3;
		c=(1/a)+(1/b);
		System.out.println("Working together, A and B can complete the work in "+String.format("%.2f", (1/c))+" days");

	}

}

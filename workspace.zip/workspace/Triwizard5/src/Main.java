import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner (System.in);
		String a,b,c;
		System.out.println("Word in the Trophy :");
		a=sc.nextLine();
		System.out.println("Malfoy picks the character :");
		b=sc.nextLine();				
		System.out.println("Malfoy replaces the character with :");
		c=sc.nextLine();
		System.out.println("Hedwig must replace "+c+" with "+b+" in the word "+a+".");
	}

}

package com.cognizant.client;
import com.cognizant.entity.*;
public class StudentClient {
	public static void main (String[] args)
	{
	Total total=new Total(); 
	
	total.input();
	
	
	total.caltotal();
	total.calPercentage();
	
	System.out.println(total);
	}
}
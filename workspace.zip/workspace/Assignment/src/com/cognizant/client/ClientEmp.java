package com.cognizant.client;
import com.cognizant.entity.*;
public class ClientEmp {
	public static void main (String[] args)
	{
		Manager mang=new Manager();
		Worker work=new Worker();
		
		mang.input();
		work.input();
		
		mang.calIncentive();
		work.calIncentive();
		
		System.out.println(mang);
		System.out.println(work);
		
	}
}

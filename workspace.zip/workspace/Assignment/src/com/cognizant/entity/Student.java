package com.cognizant.entity;
import java.util.Scanner;
public abstract class Student {
	
	protected int phy;
	protected int chem;
	protected int  maths;
	public Student() {
	}
	
	public Student(int phy ,int chem,int maths)
	{
		this.phy=phy;
		this.chem=chem;
		this.maths=maths;
	}
	
	public void input(){
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the marks of pcm");
		phy=sc.nextInt();
		chem=sc.nextInt();
		maths=sc.nextInt();
	}
	
	public abstract void caltotal();
	public abstract void calPercentage();
}

package com.cognizant.entity;
import java.util.*;
public class Total extends Student{
	protected float totalmarks;
	protected float per;
	
	public Total(){
		super();
	}
	
	public Total(int phy,int chem,int maths,float totalmarks,float per){
		super(phy,chem,maths);
		this.totalmarks=totalmarks;
		this.per=per;
	}
	
	public void input(){
		Scanner sc=new Scanner(System.in);
		super.input();
	}
	@Override
	public void caltotal(){
		totalmarks= phy+chem+maths;
	}
	@Override
	public void calPercentage(){
		per= (totalmarks*100)/300;
	}
	
	@Override
	public String toString() {
		return "Total [totalmarks=" + totalmarks + ", per=" + per + "]";
	}
}

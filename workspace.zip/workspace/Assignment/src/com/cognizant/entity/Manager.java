package com.cognizant.entity;

import java.util.Scanner;

public class Manager extends Employee {
	
	private float target;
	public Manager()
	{
		super();
	}
	public Manager (int empid,String name,float salary,float target){
		super(empid,name,salary);
		this.target=target;
	}
	
	public void input()
	{
		Scanner sc=new Scanner(System.in);
		super.input();
		System.out.println("enter the target  completed");
		target=sc.nextFloat();
	}
	public float getTarget() {
		return target;
	}
	public void setTarget(float target) {
		this.target = target;
	}
	@Override
	public void calIncentive(){
		this.finalsal=this.salary+((this.salary*target)/100);
	}
	@Override
	public String toString() {
		return "Manager [target=" + target + ", salary=" + salary + ", finalsal=" + finalsal + ", getTarget()="
				+ getTarget() + ", getEmpid()=" + getEmpid() + ", getName()=" + getName() + ", getSalary()="
				+ getSalary() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}

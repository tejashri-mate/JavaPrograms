package com.cognizant.entity;

import java.util.Scanner;

public abstract class Employee {


		private int empid;
		private String name;
		protected float salary;
		protected float finalsal;
		
		public Employee(){
			
		}
		
		public Employee(int empid,String name,float salary){
			this.empid=empid;
			this.name=name;
			this.salary=salary;
		}
		public void input(){
			Scanner sc=new Scanner(System.in);
			 
			 System.out.println("enter emp id:");
			 empid=sc.nextInt();
			       sc.nextLine();
			       
			 System.out.println("enter name:");
					 name= sc.nextLine();
					       
			  System.out.println("enter salary:");
							 salary=sc.nextFloat();
							       sc.nextLine();	       
		}

		public int getEmpid() {
			return empid;
		}

		public void setEmpid(int empid) {
			this.empid = empid;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public float getSalary() {
			return salary;
		}

		public void setSalary(float salary) {
			this.salary = salary;
		}
		public abstract void calIncentive();
		
	}


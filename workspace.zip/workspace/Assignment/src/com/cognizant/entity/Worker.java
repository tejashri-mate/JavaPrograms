package com.cognizant.entity;
import java.util.*;
public class Worker extends Employee {
	
	private float peice;
	public Worker()
	{
		super();
	}
	public Worker (int empid,String name,float salary,float peice){
		super(empid,name,salary);
		this.peice=peice;
	}
	
	public void input()
	{
		Scanner sc=new Scanner(System.in);
		super.input();
		System.out.println("enter the peices completed");
		peice=sc.nextFloat();
	}
	
	public float getPeice() {
		return peice;
	}
	public void setPeice(float peice) {
		this.peice = peice;
	}
	@Override
	public void calIncentive(){
		this.finalsal=this.salary+(peice*100);
	}
	@Override
	public String toString() {
		return "Worker [peice=" + peice + ", salary=" + salary + ", finalsal=" + finalsal + "]";
	}
	
}

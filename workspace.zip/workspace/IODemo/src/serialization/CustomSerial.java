package serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class CustomSerial {
	public static void main(String[] args) {

		FileOutputStream fos = null;
		FileInputStream fis = null;
		
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		
		Employee e = new Employee();
		
		e.input();
		
		try{
			fos = new FileOutputStream("CustomObjects.ser");
			oos = new ObjectOutputStream(fos);	
			oos.writeObject(e);
		}catch(IOException ie){
			System.out.println("Problem in IO.");
			ie.printStackTrace();
		}finally{
			try {
				oos.close();
			} catch (IOException ie) {
				ie.printStackTrace();
			}
		}
		
		try{
			fis = new FileInputStream("CustomObjects.ser");
			ois = new ObjectInputStream(fis);
			
			try {
				e = (Employee)ois.readObject();
			} catch (ClassNotFoundException cnfe) {
				cnfe.printStackTrace();
			}
		}catch(IOException ie){
			System.out.println("Problem in IO.");
			ie.printStackTrace();
		}finally{
			try {
				ois.close();
			} catch (IOException ie) {
				ie.printStackTrace();
			}
		}
		
		System.out.println("Data read from file is as follows:");
		System.out.println(e);
	}
}
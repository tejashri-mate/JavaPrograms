package characterDemo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class LendAHand1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		char[] cbuf = {'h','i','\n','t','h','e','r','e'};
		String str = new String(cbuf);
		StringBuffer sbf = new StringBuffer(str);
		sbf.reverse();
		System.out.println(sbf);*/
		
		FileReader fr = null;
		BufferedReader br= null;
		String line = null;
		StringBuffer buffer = new StringBuffer(20);
		File file = new File("Buffer.txt");
		char[] buf = null;
		try{
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			int len = (int)file.length();
			System.out.println("Length: " + len);
			buf = new char[len];
			br.read(buf, 0, len);
			
			line = new String(buf,0,len);
			System.out.println(line);
			buffer = new StringBuffer(line);
			System.out.println("buffer:"+buffer);
			buffer.reverse();
			System.out.println("reverse buffer:"+buffer);
			/*line = new String(buffer);
			System.out.println("The reverse file content is " + buffer);*/
		}catch (IOException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}
}
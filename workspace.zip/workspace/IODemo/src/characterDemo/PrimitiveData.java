package characterDemo;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrimitiveData {
	public static void main(String[] args) {
		FileWriter fw = null;
		FileReader fr = null;
		
		PrintWriter pw = null;
		
		char ch = 'A';
		byte b = 120;
		short s = 30000;
		int i = 65535;
		float f = 56.78f;
		double d = 88.98;
		
		try{
			fw = new FileWriter("simplePrim.txt");
			pw = new PrintWriter(fw);
			
			pw.println(ch);
			pw.println(b);
			pw.println(s);
			pw.println(i);
			pw.println(f);
			pw.println(d);
			
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				fw.close();
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
		
		try{
			fr = new FileReader("simplePrim.txt");
			int c;
			
			while((c = fr.read()) != -1)
				System.out.print((char)c);
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				fr.close();
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
	}
}
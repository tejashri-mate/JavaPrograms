package characterDemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadNWrite {
	public static void main(String[] args) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		FileReader fr = null;
		BufferedReader br = null;
		
		char c[] = {'a','b','c','d','e'};
		int a = 65;
		String s1 = "newAbc";
		try{
			fw = new FileWriter("simple.txt");
			bw = new BufferedWriter(fw,1000);
			bw.write(a);
			bw.write(c);
			bw.write(s1);
			
			bw.flush();
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				bw.close();
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
		
		try{
			fr = new FileReader("simple.txt");
			br = new BufferedReader(fr,1000);
			String s ;
			int ch;
			
			a = br.read();
			br.read(c);
			s = new String(c);
			
			System.out.println((char)a);
			System.out.println(s);
			
			while((ch = br.read()) != -1)
				System.out.print((char)ch);
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				br.close();
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
	}
}
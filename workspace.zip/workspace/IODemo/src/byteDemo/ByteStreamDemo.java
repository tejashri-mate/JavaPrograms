package byteDemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo {
	public static void main(String[] args) {
		FileOutputStream fos = null;
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		int value = 0;
		//byte contents[] = null;
		
		try{
			fis = new FileInputStream("abc.txt");
			fos = new FileOutputStream("c:"+File.separator+"target100.txt",true);
			//contents = new byte[fis.available()];
			
		bis = new BufferedInputStream(fis, 1200);
			bos = new BufferedOutputStream(fos, 1200);
			
			//fis.read(contents);
			value = fis.read();
			while(value != -1){//Whether EOF has been reached.
				fos.write(value);
				value=fis.read();
			}
			//fos.flush();//Written to disk.
			
			//bos.write(contents);
		}catch(IOException fnfe){
			System.out.println(fnfe.getMessage());
		}finally{
			try{
				if(bis != null){
					bis.close();
				}
				if(bos != null){
					bos.close();
				}
			}catch(IOException ie){
				System.out.println("Error while reading the file");
			}
		}
		System.out.println("Done with copying file.");
	}
}
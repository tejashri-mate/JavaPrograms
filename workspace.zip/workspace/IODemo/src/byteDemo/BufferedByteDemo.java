package byteDemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedByteDemo {
	public static void main(String[] args) {
		
		FileOutputStream fos = null;
		FileInputStream fis = null;
		
		DataOutputStream dos = null;
		DataInputStream dis = null;
		
		BufferedOutputStream bos = null;
		BufferedInputStream bis = null;
		
		//Write into the file.
		try{
			fos = new FileOutputStream("Bufferedprimitives.data");
			bos = new BufferedOutputStream(fos);
			dos = new DataOutputStream(bos);
			//writeX
			dos.writeChar('C');
			dos.writeByte(120);
			dos.writeShort(30000);
			dos.writeInt(54000);
			dos.writeFloat(23.34f);
			dos.writeDouble(10.90);
			dos.writeUTF("Hello");
			dos.flush();
		}catch(IOException ie){
			System.out.println("File cannot be opened.");
		}finally{
			try{
				dos.close();
			}catch(IOException ie){
				System.out.println("File couldn't be closed.");
			}
		}
		// Read the file.
		
		try{
			fis = new FileInputStream("Bufferedprimitives.data");
			bis = new BufferedInputStream(fis);
			dis = new DataInputStream(bis);
			//readX
			char c = dis.readChar();
			byte b = dis.readByte();
			short s = dis.readShort();
			int i = dis.readInt();
			float f = dis.readFloat();
			double d = dis.readDouble();
			String str = dis.readUTF();
			
			System.out.println(c);
			System.out.println(b);
			System.out.println(s);
			System.out.println(i);
			System.out.println(f);
			System.out.println(d);
			System.out.println(str);
			
		}catch(IOException ie){
			System.out.println("File cannot be opened.");
		}finally{
			try{
				dis.close();
			}catch(IOException ie){
				System.out.println("File couldn't be closed.");
			}
		}
	}
}
package byteDemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo7 {
	public static void main(String[] args) {
		
		int value = 0;
		
		/*
		 * Files are automatically closed when execution of this try block is
		 * over. It is because from Java 7 all io stream classes implement one
		 * interface known as Autocloseable. When these resources are opened in
		 * try-with-resources block, they are automatically closed after block
		 * execution. This is more concise code & easily maintainable.
		 */
		try(FileInputStream fis = new FileInputStream("e:\\abc.txt");
			FileOutputStream fos = new FileOutputStream("e:\\target44.txt");
				
   			BufferedInputStream	bis = new BufferedInputStream(fis, 1200);
			BufferedOutputStream bos = new BufferedOutputStream(fos, 1200);){
			
			
			//fis.read(contents);
			value = bis.read();
			while(value != -1){
				bos.write(value);
				value=bis.read();
			}
			bos.flush();
		}catch(IOException fnfe){
			System.out.println("File is not found.");
		}
		System.out.println("Done with copying file.");
	}
}
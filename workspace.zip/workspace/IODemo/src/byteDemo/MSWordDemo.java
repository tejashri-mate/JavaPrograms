package byteDemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MSWordDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FileOutputStream fos = null;
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		int value = 0;
		//byte buffer[] = null;
		try{
			fis = new FileInputStream("C:\\Users\\Bhalchandra\\Documents\\string.docx");
			fos = new FileOutputStream("C:\\Users\\Bhalchandra\\Documents\\other_string.docx");
			
			bis = new BufferedInputStream(fis, 1200);
			bos = new BufferedOutputStream(fos, 1200);
			try{
				/*buffer = new byte[fis.available()];
				fis.read(buffer);*/
			while((value=bis.read()) != -1){
				bos.write(value);
			}
				/*bos.write(buffer);*/
			}catch(IOException ie){
				System.out.println("Error while reading the file");
			}
		}catch(FileNotFoundException fnfe){
			System.out.println("File is not found.");
		}finally{
			try{
				if(bis != null){
					bis.close();
				}
				if(bos != null){
					bos.close();
				}
			}catch(IOException ie){
				System.out.println("Error while reading the file");
			}
		}
		System.out.println("Done with copying file.");
	}
}
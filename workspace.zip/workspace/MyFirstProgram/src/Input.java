import java.util.concurrent.SynchronousQueue;

public class Input {

	public static void main(String[] args) {
		boolean isItTrue = true;
		
		char alphabet='a';
		
		byte age =22;
		short distance =32000;
		int number = 9876;
		long travelTime = 1000;
		
		float percent =56.90f;
		double temprature = 120.54;
		
		System.out.println("Is it True? "+ isItTrue);
		System.out.println("alphabet: "+ alphabet);
		System.out.println("age: " + age);
		System.out.println("Distance:"+ distance);
		System.out.println("num : "+ number);
		System.out.println("travelling time in mili"+ travelTime);
		System.out.println("% ="+ percent);
		System.out.println("temp: "+ temprature);
	}

}

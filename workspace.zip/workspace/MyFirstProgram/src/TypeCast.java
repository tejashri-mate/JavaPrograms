
public class TypeCast {

	public static void main(String[] args) {
		byte age = 60;
		int number = 40;
		
		//number = number+age;
		//age=(byte)(age+number);
		age += number;
		float temp = 25.87f;
		number = (int)temp;
		System.out.println(age);

	}

}

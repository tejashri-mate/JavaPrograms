import java.util.*;
public class Area {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		double a,b,c,d,e;
		System.out.println("enter the radius");
		a=sc.nextDouble();
		d=Math.PI*a*a;
		System.out.println("Area of circle: "+ d);
		System.out.println("enter the radius and height");
		b=sc.nextDouble();
		c=sc.nextDouble();
		e= Math.PI*b*b*c;
		System.out.println("vol of cylinder: "+ e);
		sc.close();
	}
}
